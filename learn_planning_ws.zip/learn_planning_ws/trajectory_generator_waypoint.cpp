#include "trajectory_generator_waypoint.h"
#include <fstream>
#include <iostream>
#include <ros/console.h>
#include <ros/ros.h>
#include <stdio.h>
#include <string>

using namespace std;
using namespace Eigen;

#define inf 1 >> 30

TrajectoryGeneratorWaypoint::TrajectoryGeneratorWaypoint() {}

TrajectoryGeneratorWaypoint::~TrajectoryGeneratorWaypoint() {}

// Eigen::MatrixXd TrajectoryGeneratorWaypoint::PolyQPGeneration(
//     const int d_order,           // the order of derivative
//     const Eigen::MatrixXd &Path, // waypoints coordinates (3d)
//     const Eigen::MatrixXd &Vel,  // boundary velocity
//     const Eigen::MatrixXd &Acc,  // boundary acceleration
//     const Eigen::VectorXd &Time) // time allocation in each segment
// {
//   // enforce initial and final velocity and accleration, for higher order
//   // derivatives, just assume them be 0;

//   //d_order  =====  3 
//   int p_order = 2 * d_order - 1; // the order of polynomial
//   int p_num1d = p_order + 1;     // the number of variables in each segment

//   int m = Time.size();
//   cout << "Time.size is " << m << endl;
//   // MatrixXd PolyCoeff(3, 3 * p_num1d);
//   Eigen::MatrixX3d coefficientMatrix;

//   int waypoint_num = Path.rows();
//   /**
//    *
//    * STEP 3.2:  generate a minimum-jerk piecewise monomial polynomial-based
//    * trajectory
//    *
//    * **/
//     // coefficientMatrix is a matrix with 6*piece num rows and 3 columes
//     // As for a polynomial c0+c1*t+c2*t^2+c3*t^3+c4*t^4+c5*t^5,
//     // each 6*3 sub-block of coefficientMatrix is
//     // --              --
//     // | c0_x c0_y c0_z |
//     // | c1_x c1_y c1_z |
//     // | c2_x c2_y c2_z |
//     // | c3_x c3_y c3_z |
//     // | c4_x c4_y c4_z |
//     // | c5_x c5_y c5_z |
//     // --              --
//     // Please computed coefficientMatrix of the minimum-jerk trajectory
//     // in this function

//     // ------------------------ Put your solution below ------------------------

//     int temp = m-1;
//     //cout << temp <<endl;
//     // Eigen::MatrixXd M(6*temp+6 , 6 *temp +6);
//     // Eigen::MatrixXd b;
//     Eigen::MatrixXd M = Eigen::MatrixXd::Zero(6*temp+6 , 6*temp +6);
//     Eigen::MatrixXd b = Eigen::MatrixXd::Zero(6 * temp+6 , 3);
//     // Eigen::MatrixXd M;
//     // Eigen::MatrixXd b;
//     Eigen::MatrixXd Ei(6,6);
//     Eigen::MatrixXd Fi(6,6);
//     //ROS_INFO("_________ok0___________");
//     Fi << 
//     0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
//     -1., 0.0, 0.0, 0.0, 0.0, 0.0,
//     0.0, -1., 0.0, 0.0, 0.0, 0.0,
//     0.0, 0.0, -2., 0.0, 0.0, 0.0,
//     0.0, 0.0, 0.0, -6., 0.0, 0.0,
//     0.0, 0.0, 0.0, 0.0, -24., 0.0;
//     //Eigen::Vector3d pos_0 =(initialPos(0),initialPos(1),initialPos(2));
//     //ROS_INFO("_________ok1___________");

//     Eigen::Matrix3d D0;
//     Eigen::Matrix3d DM;
//     //double pos_start_x = initialPos(0);
//     D0 << Path(0,0),Path(0,1),Path(0,2),
//     Vel(0,0) , Vel(0,1), Vel(0,2),
//     Acc(0,0) , Acc(0,1), Acc(0,2);

//     DM << Path((waypoint_num-1),0) , Path((waypoint_num-1),1) , Path((waypoint_num-1),2),
//     Vel(1,0) , Vel(1,1), Vel(1,2),
//     Acc(1,0) , Acc(1,1), Acc(1,2);

//     Eigen::MatrixXd F0(3,6);
//     Eigen::MatrixXd EM(3,6);

//     F0 <<  
//     1, 0, 0, 0, 0, 0,
//     0, 1, 0, 0, 0, 0,
//     0, 0, 2, 0, 0, 0;
//     //ROS_INFO("_________ok___________");

//     // double T = Time.sum();
//     double T = Time(m-1);
//     cout << "the sum of t is " << T <<endl;
//     EM << 
//     1, T, T*T, T*T*T, T*T*T*T, T*T*T*T*T,
//     0, 1, 2*T, 3*T*T, 4*T*T*T, 5*T*T*T*T,
//     0, 0, 2, 6*T, 12*T*T, 20*T*T*T;
//     //cout << "ok______________________" <<endl;
    
//     M.block(0,0,3,6) = F0;
//     b.block(0, 0 ,3, 3) = D0;
//     cout << "Path rows " << Path.rows() <<endl;
//     cout << Path <<endl;
//     MatrixXd newPath(Path.rows() - 2, 3);
//     newPath = Path.block(1, 0, Path.rows() - 2, 3); // 从第2行开始，取 numRows - 2 行，3 列
//     cout << "newPath rows  "<< newPath.rows() << endl;
//     cout << newPath <<endl;
//     for(int i=0 ; i < temp ; i++)
//     {
//         //cout << i << endl;
//         double t = Time(i);
//         //cout << t << endl;
//         if(i < temp){
//             Ei <<
//             1, t, pow(t,2), pow(t,3), pow(t,4), pow(t,5),
//             1, t, pow(t,2), pow(t,3), pow(t,4), pow(t,5),
//             0, 1, 2*t, 3*pow(t,2), 4*pow(t,3), 5*pow(t,4),
//             0, 0, 2, 6*t, 12*pow(t,2), 20* pow(t,3),
//             0, 0, 0, 6, 24*t, 60*pow(t,2),
//             0, 0, 0, 0, 24, 120*t;
//             //cout << "Ei: " << endl;
//             M.block(i*6+3,i*6,6,6) = Ei;
//             //cout << M.block(i*6+3, i*6, 6, 6) << endl;
//             //cout << "Fi: " << endl;
//             M.block(i*6+3,i*6+6,6,6) = Fi;
//             //cout << M.block(i*6+3, i*6+6, 6, 6) << endl;
//             b.block(i*6+3,0,1,3) << newPath.row(i);
//             //cout << 2.1 << endl;
//         }
        
//     }
//     //cout << F0.block(0,0,2,2) <<endl;
    
//     M.block(temp * 6 + 3 ,temp * 6, 3 , 6) = EM;
//     b.block(temp*6 + 3, 0 ,3, 3) = DM;
//     cout << "__________________START QP Solver___________________" << endl;
//     // Solve Mc = b, using QR solver
//     clock_t time_stt = clock();
//     for (int i = 0; i < 3; i++)
//     {
//         coefficientMatrix.col(i) = M.colPivHouseholderQr().solve(b.col(i));
//         // coefficientMatrix.col(i) = M.lu().solve(b.col(i));
//     }

//     // std::cout << "C is " << coefficientMatrix << std::endl;
//     std::cout << "Time cost = " << 1000 * (clock() - time_stt) / (double)CLOCKS_PER_SEC << "ms" << std::endl;

//   return coefficientMatrix.transpose();
// }

//define factorial function, input i, output i!
int TrajectoryGeneratorWaypoint::Factorial(int x)
{
    int fac = 1;
    for(int i = x; i > 0; i--)
        fac = fac * i;
    return fac;
}


MatrixXd TrajectoryGeneratorWaypoint::getCt(int const n_seg, int const d_order){ // d_order is 4
    /*
     * get Selection Matrix
     * args:
     *      n_seg: the number of segments
     *      d_order: the deferential order: if minimal jerk. it is 3,
     * return:
     *      Ct: a matrix,
     *      row corresponds to original variable vector d ( 2 * d_order * n_seg )
     *      column corresponds to [ dF, dP ]' ( d_order*2*n_seg - (n_seg-1)*d_order )
     *      Note: the variables implicitly eliminates same variables""
     */
    // we have n_seg segments, from 0 to n_seg-1
    int ct_rows = d_order*2*n_seg;
    int ct_cols = d_order*2*n_seg - (n_seg-1)*d_order;
    MatrixXd Ct = MatrixXd::Zero(ct_rows, ct_cols);
    vector<int> d_vector;
    for(int k = 0; k < n_seg; k ++){
        for(int t = 0; t < 2; t++){
            for(int d = 0; d < d_order; d++){
                d_vector.push_back(k*100+t*10+d);
            }
        }
    }
    int val, row;
    int col = 0; // column of one in Ct

    // fixed starting point at segment 0 in [ dF, dP ]'
    int k = 0;
    int t = 0;
    int d = 0;
    for(d = 0; d < d_order; d++){
        val = k * 100 + t * 10 + d;
        auto it = std::find(d_vector.begin(), d_vector.end(), val);
        row = std::distance(d_vector.begin(), it);
        Ct(row, col) = 1;
        col += 1;
    }
    // fixed final point at segment 0, 1, 2, n_seg-2 in [ dF, dP ]'
    t = 1;
    d = 0;
    for(k = 0; k < n_seg - 1; k++){
        val = k * 100 + t * 10 + d;
        auto it = std::find(d_vector.begin(), d_vector.end(), val);
        row = std::distance(d_vector.begin(), it);
        Ct(row, col) = 1;

        val = (k + 1) * 100 + (t - 1) * 10 + d;
        it= std::find(d_vector.begin(), d_vector.end(), val);
        row = std::distance(d_vector.begin(), it);
        Ct(row, col) = 1;

        col += 1;
    }

    // fixed final point at segment n_seg-1 in [ dF, dP ]'
    k = n_seg - 1;
    t = 1;
    d = 0;
    for(d = 0; d < d_order; d++){
        val = k * 100 + t * 10 + d;
        auto it = std::find(d_vector.begin(), d_vector.end(), val);
        row = std::distance(d_vector.begin(), it);
        Ct(row, col) = 1;
        col += 1;
    }

    // free variables at segment 0, 1, 2, n_seg-1 in [ dF, dP ]'
    k = 0;
    t = 1;
    d = 1;
    for(k = 0; k < n_seg - 1; k++){
        for(d = 1; d < d_order; d++){
            val = k * 100 + t * 10 + d;
            auto it = std::find(d_vector.begin(), d_vector.end(), val);
            row = std::distance(d_vector.begin(), it);
            Ct(row, col) = 1;

            val = (k + 1) * 100 + (t - 1) * 10 + d;
            it = std::find(d_vector.begin(), d_vector.end(), val);
            row = std::distance(d_vector.begin(), it);
            Ct(row, col) = 1;

            col += 1;
        }

    }
    return Ct;
}

MatrixXd TrajectoryGeneratorWaypoint::getM(int const n_seg, int const d_order, int const p_num1d, const Eigen::VectorXd &ts){
    /*
     * get Mapping Matrix
     * args:
     *      n_seg: the number of segments
     *      d_order: the deferential order: if minimal jerk. it is 3,
     *      p_num1d: the number of variables in each segment, if minimal jerk, it is 6
     *      ts: time allocation as a column vector, size: n_seg x 1,
     * return:
     *      M: a matrix, size: n_seg * p_num1d x n_seg * p_num1d
     */
//    MatrixXd M, M_temp, zeros;
    MatrixXd M = MatrixXd::Zero(n_seg * p_num1d, n_seg * p_num1d);
    MatrixXd coeff(d_order, p_num1d);
    if(d_order == 4){
        coeff << 1,  1,  1,  1,  1,  1,  1,  1,
                 0,  1,  2,  3,  4,  5,  6,  7,
                 0,  0,  2,  6,  12, 20, 30, 42,
                 0,  0,  0,  6,  24, 60, 120,210;
    }
    else if(d_order == 3){
        coeff << 1,  1,  1,  1,  1,  1,
                 0,  1,  2,  3,  4,  5,
                 0,  0,  2,  6,  12, 20;

    }
    else{
        cout << "This derivatieve order is not provided getM!!!" << endl;
    }


    double t;
    for(int k = 0; k < n_seg; k++){
        // calculate M_k of the k-th segment
        MatrixXd M_k = MatrixXd::Zero(p_num1d, p_num1d); // Matrix size: p_num1d x p_num1d
        // time of the k-th segment
        t = ts(k);
        for(int i = 0; i < d_order; i++){
            M_k(i, i) = coeff(i, i);
        }

        for(int i = 0; i < d_order; i++){
            for(int j = i; j < p_num1d; j++){
                if( i == j){
                    M_k(i+d_order, j) = coeff(i, j) ;
                }
                else{
                    M_k(i+d_order, j) = coeff(i, j) * pow(t, j - i);
                }
            }
        }




        M.block(k*p_num1d, k*p_num1d, p_num1d, p_num1d) = M_k;
    }
    return M;
}

Eigen::MatrixXd TrajectoryGeneratorWaypoint::getQ(int const n_seg, int const d_order, int const p_num1d, const Eigen::VectorXd &ts){
    /*
     * get Q matrix
     * args:
     *      n_seg: the number of segments
     *      d_order: the deferential order: if minimal snap. it is 4
     *      p_num1d: the number of variables in each segment
     *      ts: time allocation as a column vector, size: n_seg x 1,
     * return:
     *      Q: a matrix, size: n_seg * p_num1d x n_seg * p_num1d
     *      Note: p = [p0, p1, p2,...pn-1]'
     */

    MatrixXd Q = MatrixXd::Zero(n_seg * p_num1d, n_seg * p_num1d);
    for(int k = 0; k < n_seg; k++) {
        Eigen::MatrixXd Q_k = Eigen::MatrixXd::Zero(p_num1d, p_num1d); // Matrix size: p_num1d x p_num1d
        for (int i = 0; i < p_num1d; i++) {
            for (int j = 0; j < p_num1d; j++) {
                if (i < d_order || j < d_order)
                    continue;
                else
                    Q_k(i, j) = 1.0 * Factorial(i) / Factorial(i - d_order) * Factorial(j) /
                                    Factorial(j - d_order) /
                                    (i + j - d_order * 2 + 1) * pow(ts(k), i + j - 2 * d_order + 1);
            }

        }
        Q.block(k * p_num1d, k * p_num1d, p_num1d, p_num1d) = Q_k;
    }
    return Q;
}


/*

    STEP 2: Learn the "Closed-form solution to minimum snap" in L5, then finish this PolyQPGeneration function

    variable declaration: input       const int d_order,                    // the order of derivative
                                      const Eigen::MatrixXd &Path,          // waypoints coordinates (3d)
                                      const Eigen::MatrixXd &Vel,           // boundary velocity
                                      const Eigen::MatrixXd &Acc,           // boundary acceleration
                                      const Eigen::VectorXd &Time)          // time allocation in each segment
                          output      MatrixXd PolyCoeff(n_segment, 3 * p_num1d);   // position(x,y,z), so we need (3 * p_num1d) coefficients

*/

Eigen::MatrixXd TrajectoryGeneratorWaypoint::PolyQPGeneration(
            const int d_order,                    // the order of derivative
            const Eigen::MatrixXd &Path,          // waypoints coordinates (3d)
            const Eigen::MatrixXd &Vel,           // boundary velocity
            const Eigen::MatrixXd &Acc,           // boundary acceleration
            const Eigen::VectorXd &Time)          // time allocation in each segment
{
    // enforce initial and final velocity and acceleration, for higher order derivatives, just assume them be 0;
    int p_order   = 2 * d_order - 1;              // the order of polynomial
    int p_num1d   = p_order + 1;                  // the number of variables in each segment

    int n_segment = Time.size();                              // the number of segments
    MatrixXd PolyCoeff = MatrixXd::Zero(n_segment, 3 * p_num1d);           // position(x,y,z), so we need (3 * p_num1d) coefficients
    VectorXd Px(p_num1d * n_segment), Py(p_num1d * n_segment), Pz(p_num1d * n_segment);

    // get Q
    MatrixXd Q = getQ(n_segment, d_order,  p_num1d, Time);
    //cout << "Matrix Q is:\n"<< endl << Q << endl;

    /* Produce Mapping Matrix  to the entire trajectory,
     * M is a mapping matrix that maps polynomial coefficients to derivatives.   */
    MatrixXd M = getM(n_segment, d_order,  p_num1d, Time);
    //cout << "Mapping matrix M is:\n" << endl << M << endl;


    // compute Ct
    MatrixXd Ct = getCt(n_segment, d_order);
    //cout <<"Ct: \n"<< endl << Ct << endl;

    MatrixXd C = Ct.transpose();
    //cout << "C is:\n" << endl << C << endl;

    MatrixXd M_inv = M.inverse();
    MatrixXd M_inv_t = M_inv.transpose();

    // cout << "M_inv is:" << endl << M_inv << endl;
    // cout << "M_inv_transp is:" << endl << M_inv_t << endl;
    // cout << "size of C is: " << C.rows() << ", " << C.cols() << endl;
    // cout << "size of M_inv_t is: " << M_inv_t.rows()  << ", " <<  M_inv_t.cols() << endl;
    // cout << "size of Q  is: " << Q.rows()  << ", " << Q.cols()  << endl;
    // cout << "size of M_inv  is: " << M_inv.cols() << ", " << M_inv.rows() << endl;
    // cout << "size of Ct  is: " << Ct.rows() << ", " << Ct.cols() << endl;

    MatrixXd R = C * M_inv_t * Q * M_inv * Ct; // M is not changed
    //cout << "R is:\n" << endl << C << endl;

    int num_d_F = 2 * d_order + n_segment - 1;
    int num_d_P = (n_segment - 1) * (d_order - 1);

    MatrixXd R_pp = R.bottomRightCorner(num_d_P, num_d_P);
    //cout << "R_pp is:\n" << endl << C << endl;

    MatrixXd R_fp = R.topRightCorner(num_d_F, num_d_P);
    //cout << "R_fp is:\n" << endl << C << endl;



    // STEP 3: compute dF for x, y, z respectively
    for(int dim = 0; dim < 3; dim++){
        VectorXd wayPoints = Path.col(dim);
        //cout << "waypoints: " << endl << wayPoints << endl;
        VectorXd d_F = VectorXd::Zero(num_d_F);

        d_F(0) = wayPoints(0); //p0
        // v0,0 a0,0 ... are 0

        // pT,0, pT,1, ,,PT,n_seg-2
        for(int i = 0; i < n_segment - 1; i++ ){
            d_F(d_order + i) = wayPoints(i + 1);
        }
        // pT,n_seg-1
        d_F(d_order + n_segment - 1) = wayPoints(n_segment);
        //cout << "d_F is:" << endl << d_F << endl;

        VectorXd d_P = -1.0 * R_pp.inverse() * R_fp.transpose() * d_F;
        //cout << "d_P is:" << endl << d_P << endl;

        VectorXd d_total(d_F.rows() + d_P.rows());
        d_total << d_F, d_P;
        //cout << "d_total is:" << endl << d_total << endl;

        VectorXd poly_coef_1d = M.inverse() * Ct * d_total;
        //cout<< "Dimension " << dim <<" coefficients: "<< endl << poly_coef_1d << endl;

        //cout << "PolyCoeff.block(0, dim*p_num1d, n_segment, p_num1d) :" << endl
        //    << PolyCoeff.block(0, dim*p_num1d, n_segment, p_num1d) << endl;
        MatrixXd poly_coef_1d_t = poly_coef_1d.transpose();
        //cout << "poly_coef_1d.transpose() :" << endl << poly_coef_1d_t << endl;
        // PolyCoeff(n_segment, 3 * p_num1d)
        for(int k = 0; k < n_segment; k++){
            PolyCoeff.block(k, dim*p_num1d, 1, p_num1d) = poly_coef_1d_t.block(0,k*p_num1d, 1, p_num1d);
        }

    }
    //cout << "PolyCoeff :" << endl << PolyCoeff << endl;
    return PolyCoeff;
}


double TrajectoryGeneratorWaypoint::getObjective() {
  _qp_cost = (_Px.transpose() * _Q * _Px + _Py.transpose() * _Q * _Py +
              _Pz.transpose() * _Q * _Pz)(0);
  return _qp_cost;
}

Vector3d TrajectoryGeneratorWaypoint::getPosPoly(MatrixXd polyCoeff, int k,
                                                 double t) {
  
  //k  -> segement
  Vector3d ret;
  int _poly_num1D = (int)polyCoeff.cols() / 3;
  for (int dim = 0; dim < 3; dim++) {
    VectorXd coeff = (polyCoeff.row(k)).segment(dim * _poly_num1D, _poly_num1D);
    VectorXd time = VectorXd::Zero(_poly_num1D);

    for (int j = 0; j < _poly_num1D; j++)
      if (j == 0)
        time(j) = 1.0;
      else
        time(j) = pow(t, j);

    ret(dim) = coeff.dot(time);  //计算点ji
    // cout << "dim:" << dim << " coeff:" << coeff << endl;
  }

  return ret;
}

Vector3d TrajectoryGeneratorWaypoint::getVelPoly(MatrixXd polyCoeff, int k,
                                                 double t) {
  Vector3d ret;
  int _poly_num1D = (int)polyCoeff.cols() / 3;
  for (int dim = 0; dim < 3; dim++) {
    VectorXd coeff = (polyCoeff.row(k)).segment(dim * _poly_num1D, _poly_num1D);
    VectorXd time = VectorXd::Zero(_poly_num1D);

    for (int j = 0; j < _poly_num1D; j++)
      if (j == 0)
        time(j) = 0.0;
      else
        time(j) = j * pow(t, j - 1);

    ret(dim) = coeff.dot(time);
  }

  return ret;
}

Vector3d TrajectoryGeneratorWaypoint::getAccPoly(MatrixXd polyCoeff, int k,
                                                 double t) {
  Vector3d ret;
  int _poly_num1D = (int)polyCoeff.cols() / 3;
  for (int dim = 0; dim < 3; dim++) {
    VectorXd coeff = (polyCoeff.row(k)).segment(dim * _poly_num1D, _poly_num1D);
    VectorXd time = VectorXd::Zero(_poly_num1D);

    for (int j = 0; j < _poly_num1D; j++)
      if (j == 0 || j == 1)
        time(j) = 0.0;
      else
        time(j) = j * (j - 1) * pow(t, j - 2);

    ret(dim) = coeff.dot(time);
  }

  return ret;
}