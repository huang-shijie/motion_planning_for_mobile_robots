
"use strict";

let output_point = require('./output_point.js');
let input_point = require('./input_point.js');

module.exports = {
  output_point: output_point,
  input_point: input_point,
};
